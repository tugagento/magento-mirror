<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Bundle\Test\Block\Catalog\Product\View\Type\Option;

/**
 * Class Checkbox
 * Bundle option checkbox type
 */
class Checkbox extends Radiobuttons
{
    // Parent behavior
}
