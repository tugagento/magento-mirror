<?php

require_once 'Zend/Exception.php';

class Zend_Loader_Exception extends Zend_Exception 
{
    
}